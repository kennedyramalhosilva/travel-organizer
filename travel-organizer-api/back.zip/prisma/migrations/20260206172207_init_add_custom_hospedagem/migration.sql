-- AlterTable
ALTER TABLE "Viagem" ADD COLUMN "custoHospedagem" REAL;
