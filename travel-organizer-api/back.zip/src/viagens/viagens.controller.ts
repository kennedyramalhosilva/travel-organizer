import { Controller } from '@nestjs/common';

@Controller('viagens')
export class ViagensController {}
